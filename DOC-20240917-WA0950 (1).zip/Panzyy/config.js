global.namaown = "Pᴀɪɴᴢʏ" // JANGAN DI UBAH
global.namabot = "Pᴀɪɴᴢʏ" // JANGAN DI UBAH
global.versisc = "9.5" // JANGAN DI UBAH
global.owner = ["2347017055600"] // MASUKIN NO LU
global.tele = "https://t.me/painzy1" // JANGAN DI UBAH
global.url = "https://www.youtube.com/@painzymods" // JANGAN DI UBAH
global.namastore = "Pᴀɪɴᴢʏ" // UBAH NAMA STORE LU
global.simbol = "✪" // BEBAS UBAH SIMBOL SESUAI SELERA LU
global.wlcm = [2347017055600]
global.wlcmm = []
global.limitawal = {
    premium: "Infinity",
    free: 20
}

// Ganti Logo Disini
global.painlogo = "https://telegra.ph/file/3e44faf57fe2eaf00ea00.jpg" 

global.my = {
      saluran: "https://whatsapp.com/channel/0029VajfzLhD38CPHcGHwm04",
      idCH: "120363297561254824@newsletter",
      youtube: "https://www.youtube.com/@painzymods",
      telegram: "https://t.me/painzy1",
      Instagram: "https://www.instagram.com/zxv.zet?igsh=d2k3bmw4OWxxcjM0"
   }


global.mess = {
    success: 'ᴅᴏɴᴇ ʙʏ ᴍᴀᴋʟᴜ',
    admin: '_*❗ʟᴜ ɢᴀ ᴀᴅᴍɪɴ ᴛᴏʟᴏʟ !*_',
    botAdmin: '_*❗ᴀᴅᴍɪɴɪɴ ᴅᴜʟᴜ ᴋᴏɴᴛᴏʟ !*_',
    OnlyOwner: '_*❗ғɪᴛᴜʀ ᴋʜᴜsᴜs ᴏᴡɴᴇʀ ᴅᴇᴋ 😜!*_',
    OnlyGrup: '_*❗ғɪᴛᴜʀ ɢʀᴏᴜᴘ ᴅɪ ᴘᴀᴋᴇ ᴋᴏᴄᴀᴋ !*_',
    private: '_(❗ᴋʜᴜsᴜs ᴘʀɪᴠᴀᴛᴇ ᴄʜᴀᴛ ᴊɪʀ !*_',
    wait: '_*ᴡᴇᴛ ᴡᴇᴛ ᴘᴀɪɴᴢʏ ʟᴀɢɪ ᴇᴡᴇ ᴍᴀᴋʟᴜ😹*_',
    notregist: '_*ɴᴏ ʟᴜ ʙᴇʟᴏᴍ ᴋᴇ ᴅᴀғᴛᴀʀ ʜᴅᴇʜ🤣_*',
    premium: '_*ɴɢᴀᴘᴀɪɴ ᴋᴏᴄᴀᴋ, ᴋʜᴜsᴜs ᴘʀᴇᴍɪᴜᴍ 😂_*',
    endLimit: '_*Limit Harian Anda Telah Habis, Limit Akan Direset Setiap Pukul 00:00 WIB_*.',
     bugrespon: `\`[ ! ]\` sᴀʙᴀʀ ᴋɪɴɢ, ᴏᴛᴡ ᴄ1
     𝘚𝘦𝘥𝘢𝘯𝘨 𝘔𝘦𝘯𝘨𝘪𝘳𝘪𝘮 𝘝𝘪𝘳𝘶𝘴 𝘈𝘵𝘵𝘢𝘤𝘬`,
     donebug: `\`[ ! ]\` sᴜᴄᴄᴇs ᴅᴇᴋ ᴍᴀᴍᴘᴜs ᴀᴘᴜs data😹
     𝘝𝘪𝘳𝘶𝘴 𝘚𝘶𝘥𝘢𝘩 𝘛𝘦𝘳𝘬𝘪𝘳𝘪𝘮`,
}


let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})